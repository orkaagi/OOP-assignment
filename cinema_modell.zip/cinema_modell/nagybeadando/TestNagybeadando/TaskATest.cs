using nagybeadando;

namespace TestNagybeadando
{
    [TestClass]
    public class TaskATest
    {
        /*                              ha a felsorolo hossza 0                             */
        [TestMethod]
        public void TaskA_helper_Length0()
        {
            List<Room> rooms = new List<Room>() { new Room(21, Category.Large), new Room(18, Category.Small) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 0);
        }

        /*    ha csak az elso elem adott tulajdonsagu (Avatar) es csak az utolso adott tulajdonsagu (Gravity)   */
        /*                  van egyezo es nem egyezo cimu film is a felsorolasban (Paddington)                  */
        [TestMethod]
        public void TaskA_helper_OnlyFirst_OnlyLast()
        {
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2) };
            Show s1 = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Seat> shows21Paddington = new List<Seat>() { new Seat('D', 1), new Seat('D', 2) };
            Show s2 = new Show("Paddington", "12:00-13:15", shows21Paddington);
            List<Seat> shows21Gravity = new List<Seat>() { new Seat('B', 1), new Seat('B', 2) };
            Show s3 = new Show("Gravity", "16:30-19:45", shows21Gravity);
            List<Show> shows21 = new List<Show>() { s1, s2, s3 };
            List<Room> room21 = new List<Room>() { new Room(21, Category.Large, shows21) };
            Cinema cinema = new Cinema("Corvin", room21);

            Viewer lili = new Viewer("Lili", s1);
            Viewer lajos = new Viewer("Lajos", s3);

            lili.Purchase(s1, 'A', 1, new Owner("Lili", Discount.Student));
            lili.Purchase(s1, 'A', 2, new Owner("Anna", Discount.Student));
            lajos.Purchase(s3, 'B', 1, new Owner("Lajos", Discount.Adult));

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Paddington"), 0);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), 1);
        }

        /*                              ha az eloadasok felsorolojanak hossza 0                            */
        [TestMethod]
        public void TaskA_ShowLength0()
        {
            List<Room> rooms = new List<Room>() { new Room(21, Category.Large), new Room(18, Category.Small) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Assert.ThrowsException<NoFilmException>(() => cinema.MostViewer());
        }

        /*                              ha a termek felsorolojanak hossza 0                            */
        [TestMethod]
        public void TaskA_RoomLength0()
        {
            Cinema cinema = new Cinema("Corvin");

            Assert.ThrowsException<NoRoomException>(() => cinema.MostViewer());
        }

        /*                              ha az elso terem elso filmjehez tartozo ertek maximalis                            */
        [TestMethod]
        public void TaskA_FirstMax()
        {
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2) };
            Show s1 = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Seat> shows21Paddington = new List<Seat>() { new Seat('D', 1), new Seat('D', 2) };
            Show s2 = new Show("Paddington", "12:00-13:15", shows21Paddington);
            List<Seat> shows18Gravity = new List<Seat>() { new Seat('B', 1) };
            Show s3 = new Show("Gravity", "16:30-19:45", shows18Gravity);            
            List<Show> shows21 = new List<Show>() { s1, s2 };
            List<Show> shows18 = new List<Show>() { s3 };
            List<Room> rooms = new List<Room>() { new Room(21, Category.Large, shows21), new Room(21, Category.Small, shows18) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Viewer lili = new Viewer("Lili", s1);
            Viewer lajos = new Viewer("Lajos", s3);

            lili.Purchase(s1, 'A', 1, new Owner("Lili", Discount.Student));
            lili.Purchase(s1, 'A', 2, new Owner("Anna", Discount.Student));
            lajos.Purchase(s3, 'B', 1, new Owner("Lajos", Discount.Adult));

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Paddington"), 0);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), 1);
            Assert.AreEqual(cinema.MostViewer(), "Avatar");
        }

        /*                              ha az utolso terem utolso filmjehez tartozo ertek maximalis                            */
        [TestMethod]
        public void TaskA_LastMax()
        {   
            List<Seat> shows18Gravity = new List<Seat>() { new Seat('B', 1), new Seat('B', 2) };
            Show s3 = new Show("Gravity", "16:30-19:45", shows18Gravity);
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2) };
            Show s1 = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Seat> shows21Paddington = new List<Seat>() { new Seat('D', 1), new Seat('D', 2) };
            Show s2 = new Show("Paddington", "12:00-13:15", shows21Paddington);
            List<Show> shows18 = new List<Show>() { s3 };
            List<Show> shows21 = new List<Show>() { s1, s2 };            
            List<Room> rooms = new List<Room>() { new Room(21, Category.Small, shows18), new Room(21, Category.Large, shows21) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Viewer lili = new Viewer("Lili", s2);
            Viewer lajos = new Viewer("Lajos", s3);

            lili.Purchase(s2, 'D', 1, new Owner("Lili", Discount.Student));
            lili.Purchase(s2, 'D', 2, new Owner("Anna", Discount.Student));
            lajos.Purchase(s3, 'B', 1, new Owner("Lajos", Discount.Adult));

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 0);
            Assert.AreEqual(cinema.FilmSoldCount("Paddington"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), 1);
            Assert.AreEqual(cinema.MostViewer(), "Paddington");
        }

        /*                              egyetlen maximalis elem van                                 */
        [TestMethod]
        public void TaskA_OnlyMax()
        {
            List<Seat> shows18Gravity = new List<Seat>() { new Seat('B', 1), new Seat('B', 2) };
            Show s3 = new Show("Gravity", "16:30-19:45", shows18Gravity);
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2) };
            Show s1 = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Seat> shows21Paddington = new List<Seat>() { new Seat('D', 1), new Seat('D', 2) };
            Show s2 = new Show("Paddington", "12:00-13:15", shows21Paddington);
            List<Show> shows18 = new List<Show>() { s3 };
            List<Show> shows21 = new List<Show>() { s1, s2 };
            List<Room> rooms = new List<Room>() { new Room(21, Category.Small, shows18), new Room(21, Category.Large, shows21) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Viewer lili = new Viewer("Lili", s2);

            lili.Purchase(s2, 'D', 1, new Owner("Lili", Discount.Student));
            lili.Purchase(s2, 'D', 2, new Owner("Anna", Discount.Student));

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 0);
            Assert.AreEqual(cinema.FilmSoldCount("Paddington"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), 0);
            Assert.AreEqual(cinema.MostViewer(), "Paddington");
        }

        /*                              tobb maximalis elem van                                 */
        [TestMethod]
        public void TaskA_MultipleMax()
        {
            List<Seat> shows18Gravity = new List<Seat>() { new Seat('B', 1), new Seat('B', 2) };
            Show s3 = new Show("Gravity", "16:30-19:45", shows18Gravity);
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2) };
            Show s1 = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Seat> shows21Paddington = new List<Seat>() { new Seat('D', 1), new Seat('D', 2) };
            Show s2 = new Show("Paddington", "12:00-13:15", shows21Paddington);
            List<Show> shows18 = new List<Show>() { s3 };
            List<Show> shows21 = new List<Show>() { s1, s2 };
            List<Room> rooms = new List<Room>() { new Room(21, Category.Small, shows18), new Room(21, Category.Large, shows21) };
            Cinema cinema = new Cinema("Corvin", rooms);

            Viewer lili = new Viewer("Lili", s2);
            Viewer lajos = new Viewer("Lajos", s3);

            lili.Purchase(s2, 'D', 1, new Owner("Lili", Discount.Student));
            lili.Purchase(s2, 'D', 2, new Owner("Anna", Discount.Student));
            lajos.Purchase(s3, 'B', 1, new Owner("Lajos", Discount.Adult));
            lajos.Purchase(s3, 'B', 2, new Owner("Lajos", Discount.Children));

            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 0);
            Assert.AreEqual(cinema.FilmSoldCount("Paddington"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), 2);
            Assert.AreEqual(cinema.FilmSoldCount("Gravity"), cinema.FilmSoldCount("Paddington"));
            Assert.AreEqual(cinema.MostViewer(), "Gravity");
        }
    }
}