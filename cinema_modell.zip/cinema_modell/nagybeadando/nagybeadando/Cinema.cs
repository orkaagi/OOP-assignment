﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public class NoFilmException : Exception { }
    public class NoRoomException : Exception { }

    public class Cinema
    {
        private readonly string name;
        public List<Room> rooms = new();

        public Cinema(string name) { this.name = name; }

        public Cinema(string name, List<Room> rooms)
        {
            this.name = name;
            foreach (Room r in rooms)
            {
                this.rooms.Add(r);
            }
        }

        public int FilmSoldCount(string title)
        {
            if (rooms.Count == 0) throw new NoRoomException();
            // egy teremhez tartozhat 0 eloadas, ebben az esetben sum = 0 marad
            int sum = 0;
            foreach (Room r in rooms)
            {
                foreach (Show s in r.shows)
                {
                    if (s.title == title)
                    {
                        sum += s.SoldCount();
                    }
                }
            }
            return sum;
        }

        public string MostViewer()
        {
            if (rooms.Count == 0) throw new NoRoomException();
            // egy teremhez tartozhat 0 eloadas, ebben az esetben l hamis marad
            bool l = false;
            int max = -1;
            string film = "";
            foreach (Room r in rooms)
            {
                foreach (Show s in r.shows)
                {
                    int curr = FilmSoldCount(s.title);
                    if (!l)
                    {
                        l = true;
                        max = curr;
                        film = s.title;
                    }
                    // tobb maximum eseten az elsot adja vissza
                    else if (l && curr > max) 
                    {
                        max = curr;
                        film = s.title;
                    }
                }
            }
            if (l)
            {
                return film;
            }
            else
            {
                throw new NoFilmException();
            }
        }

    }
}
