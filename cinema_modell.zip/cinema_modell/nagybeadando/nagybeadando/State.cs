﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public abstract class State
    {
        public virtual bool IsAvailable() { return false; }
        public virtual bool IsReserved() { return false; }
        public virtual bool IsSold() { return false; }
    }

    public class Available : State
    {
        private static Available? instance;

        private Available() { }

        public static Available Instance()
        {
            if (instance == null) instance = new Available();
            return instance;
        }

        public override bool IsAvailable() { return true; }
    }

    public class Reserved : State
    {
        private static Reserved? instance;

        private Reserved() { }

        public static Reserved Instance()
        {
            if (instance == null) instance = new Reserved();
            return instance;
        }

        public override bool IsReserved() { return true; }
    }

    public class Sold : State
    {
        private static Sold? instance;

        private Sold() { }

        public static Sold Instance()
        {
            if (instance == null) instance = new Sold();
            return instance;
        }

        public override bool IsSold() { return true; }
    }
}
