﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public enum Category { 
        VIP,
        Large,
        Small
    }

    public class Room
    {
        private readonly int number;
        private readonly Category category;

        public List<Show> shows = new();

        public Room(int number, Category category) {
            this.number = number;
            this.category = category;
        }

        public Room(int number, Category category, List<Show> shows)
        {
            this.number = number;
            this.category = category;
            foreach (Show s in shows)
            {
                this.shows.Add(s);
            }
        }
    }
}
