﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.Arm;
using TextFile;

namespace nagybeadando
{
    public class NoViewerException : Exception { }
    public class InvalidEnumInputException : Exception { }

    public class Program
    {
        static void Main(string[] args)
        {  
            try
            {
                TextFileReader reader = new TextFileReader("inputs/cinema.txt");
                char[] separators = new char[] { ' ', '\t' };
                
                reader.ReadLine(out string theatrename);
                Cinema cinema = new Cinema(theatrename);

                while (reader.ReadLine(out string filename))
                {
                    // minden roomN.txt-re
                    TextFileReader innerReader = new TextFileReader($"inputs/{filename}");                    

                    innerReader.ReadLine(out string roomdata);
                    string[] r = roomdata.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                    /* --------------------------- terem beolvasasa --------------------------- */
                    Category c;
                    if (r[1] == "VIP") { c = Category.VIP; }
                    else if (r[1] == "Large") { c = Category.Large; }
                    else if (r[1] == "Small") { c = Category.Small; }
                    else { throw new InvalidEnumInputException(); }

                    Room room = new Room(int.Parse(r[0]), c);

                    /* --------------------------- filmek szamanak beolvasasa --------------------------- */
                    innerReader.ReadLine(out string sc);
                    int ShowCount = int.Parse(sc);

                    for (int count = 0; count < ShowCount; count++)
                    {
                        /* --------------------------- eloadas beolvasasa  (film, idointerval) --------------------------- */
                        innerReader.ReadLine(out string showdata);
                        string[] sh = showdata.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                        Show show = new Show(sh[0], sh[1]);

                        /* --------------------------- szekek beolvasasa (es hozzaadasa az eloadashoz) --------------------------- */
                        innerReader.ReadLine(out string seatline);
                        string[] se = seatline.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                        for (int i = 0; i < se.Length; i += 2)
                        {
                            show.seats.Add(new Seat(char.Parse(se[i]), int.Parse(se[i + 1])));
                        }

                        /* --------------------------- nezok es tevekenysegeik beolvasasa (es hozzaadasa az eloadashoz) --------------------------- */
                        innerReader.ReadLine(out string ac);
                        int ActionCount = int.Parse(ac);
                        Viewer? viewer = null;

                        for (int count2 = 0; count2 < ActionCount; count2++)
                        {
                            innerReader.ReadLine(out string line);
                            string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            
                            switch (tokens[0])
                            {
                                case "V":
                                    viewer = new Viewer(tokens[1], show);
                                    break;
                                case "RES":
                                    if (viewer == null) throw new NoViewerException();
                                    Discount d;
                                    if (tokens[4] == "Children") { d = Discount.Children; }
                                    else if (tokens[4] == "Student") { d = Discount.Student; }
                                    else if (tokens[4] == "Adult") { d = Discount.Adult; }
                                    else if (tokens[4] == "Pensioner") { d = Discount.Pensioner; }
                                    else if (tokens[4] == "Habitue") { d = Discount.Habitue; }
                                    else { throw new InvalidEnumInputException(); }
                                    viewer.Reserve(show, char.Parse(tokens[1]), int.Parse(tokens[2]), new Owner(tokens[3], d));
                                    break;
                                case "PUR":
                                    if (viewer == null) throw new NoViewerException();
                                    Discount dp;
                                    if (tokens[4] == "Children") { dp = Discount.Children; }
                                    else if (tokens[4] == "Student") { dp = Discount.Student; }
                                    else if (tokens[4] == "Adult") { dp = Discount.Adult; }
                                    else if (tokens[4] == "Pensioner") { dp = Discount.Pensioner; }
                                    else if (tokens[4] == "Habitue") { dp = Discount.Habitue; }
                                    else { throw new InvalidEnumInputException(); }
                                    viewer.Purchase(show, char.Parse(tokens[1]), int.Parse(tokens[2]), new Owner(tokens[3], dp));
                                    break;
                            }                            
                        }
                        // eloadas hozzaadasa a teremhez
                        room.shows.Add(show);
                    }
                    // terem hozzaadasa a filmszinhazhoz
                    cinema.rooms.Add(room);
                }

                // a) feladat
                Console.WriteLine($"A legnezetteb film: {cinema.MostViewer()}.");
                Console.WriteLine();

                // b) feladat
                foreach (Room room in cinema.rooms)
                {
                    foreach (Show movie in room.shows)
                    {
                        Console.WriteLine($"A {movie.title} [{movie.interval}] eloadasra \n \t a meg szabad jegyek szama: {movie.AvaCount()}, \n \t a lefoglalt jegyek szama: {movie.ResCount()}, \n \t az eladott jegyek szama: {movie.SoldCount()}.");
                    }
                }
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("A megadott fajl nem talalhato!");
            }
        }
    }
}