﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public enum Discount
    {
        Children,
        Student,
        Adult,
        Pensioner,
        Habitue
    }

    public class Owner
    {
        public string name;
        public Discount discount;

        public Owner(string name, Discount discount)
        {
            this.name = name;
            this.discount = discount;
        }
    }
}
