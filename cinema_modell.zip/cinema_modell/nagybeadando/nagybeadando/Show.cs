﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public class NoSeatException : Exception { }

    public class Show
    {
        public string title;
        public string interval;

        public List<Seat> seats = new();

        public Show(string title, string interval)
        {
            this.title = title;
            this.interval = interval;
        }

        public Show(string title, string interval, List<Seat> seats)
        {
            this.title = title;
            this.interval = interval;
            foreach (Seat s in seats) 
            {
                this.seats.Add(s);
            }
        }

        public int AvaCount() 
        {
            if (seats.Count == 0) throw new NoSeatException();
            int sum = 0;
            foreach (Seat s in seats) 
            {
                if (s.state.IsAvailable()) sum++;
            }
            return sum;
        }

        public int ResCount()
        {
            if (seats.Count == 0) throw new NoSeatException();
            int sum = 0;
            foreach (Seat s in seats)
            {
                if (s.state.IsReserved()) sum++;
            }
            return sum;
        }

        public int SoldCount()
        {
            if (seats.Count == 0) throw new NoSeatException();
            int sum = 0;
            // Console.WriteLine("init soldcount sum = 0");
            foreach (Seat s in seats)
            {
                if (s.state.IsSold()) sum++;
                // Console.WriteLine("sum =" + sum);
            }
            return sum;
        }
    }
}
