﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public class IllegalStateChange : Exception { }

    public class Seat
    {
        public char row { get; }
        public int num { get; }

        public State state;
        public Owner? owner;

        public Seat(char row, int num)
        {
            this.row = row;
            this.num = num;
            state = Available.Instance();
            owner = null;
        }

        public void Reserve(Owner o)
        {
            if (state.IsAvailable())
            {
                owner = o;
                state = Reserved.Instance();
            }
            else throw new IllegalStateChange();
        }

        public void Sell(Owner o)
        {
            if (state.IsAvailable())
            {
                owner = o;
                state = Sold.Instance();
            }
            else if (state.IsReserved() && owner.name == o.name) 
            {
                state = Sold.Instance();
            }
            else throw new IllegalStateChange();
        }
    }   
}
