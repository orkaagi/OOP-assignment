﻿using nagybeadando;

namespace TestNagybeadando
{
    [TestClass]
    public class TaskBTest
    {
        [TestMethod]
        public void SeatConstructor()
        {
            List<Seat> shows21Avatar = new List<Seat>() {
               new Seat('A', 1), new Seat('A', 2), new Seat('B', 1), new Seat('B', 2)
            };

            Assert.AreEqual(shows21Avatar.Count, 4);
            // jo-e az alap allapot (state) beallitas            
            Assert.IsTrue(shows21Avatar[0].state.IsAvailable());
            Assert.IsFalse(shows21Avatar[0].state.IsReserved());
            Assert.IsFalse(shows21Avatar[0].state.IsSold());

            Show s = new Show("Avatar", "17:30-20:50", shows21Avatar);
            List<Show> shows21 = new List<Show>() { s };
            List<Room> rooms = new List<Room>() { new Room(21, Category.Large, shows21) };

            Cinema cinema = new Cinema("Corvin", rooms);

            Viewer lili = new Viewer("Lili", s);
            Viewer ferenc = new Viewer("Ferenc", s);

            ferenc.Reserve(s, 'A', 1, new Owner("Ferenc", Discount.Adult));
            ferenc.Purchase(s, 'A', 1, new Owner("Ferenc", Discount.Adult));
            lili.Reserve(s, 'B', 1, new Owner("Lili", Discount.Adult));

            // jo-e az egyes allapotok darabszamainak megszamolasa
            Assert.AreEqual(s.AvaCount(), 2);
            Assert.AreEqual(s.ResCount(), 1);
            Assert.AreEqual(s.SoldCount(), 1);

            // jo-e az adott filmhez tartozo egyes allapotok darabszamainak megszamolasa
            Assert.AreEqual(cinema.FilmSoldCount("Avatar"), 1);
            Assert.AreEqual(cinema.MostViewer(), "Avatar");
        }

        /*                              ha a felsorolo hossza 0                           */
        [TestMethod]
        public void TaskB_Length0()
        {
            List<Seat> shows21Avatar = new List<Seat>();
            Show s = new Show("Avatar", "17:30-20:50", shows21Avatar);
            Assert.AreEqual(s.seats.Count, 0);

            Assert.ThrowsException<NoSeatException>(() => s.AvaCount());
            Assert.ThrowsException<NoSeatException>(() => s.ResCount());
            Assert.ThrowsException<NoSeatException>(() => s.SoldCount());
        }

        /*                              ha a felsorolo hossza nem 0                           */
        [TestMethod]
        public void TaskB_LengthN()
        {
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2), new Seat('B', 1), new Seat('B', 2) };
            Show s = new Show("Avatar", "17:30-20:50", shows21Avatar);
            Assert.IsTrue(s.seats.Count > 0);

            Viewer ferenc = new Viewer("Ferenc", s);
            ferenc.Reserve(s, 'A', 1, new Owner("Ferenc", Discount.Adult));
            ferenc.Purchase(s, 'A', 1, new Owner("Ferenc", Discount.Adult));
            ferenc.Reserve(s, 'B', 1, new Owner("Anna", Discount.Adult));

            Assert.AreEqual(s.AvaCount(), 2);
            Assert.AreEqual(s.ResCount(), 1);
            Assert.AreEqual(s.SoldCount(), 1);
        }

        /*    ha csak az elso elem adott tulajdonsagu (foglalt) es csak az utolso adott tulajdonsagu (eladott)   */
        [TestMethod]
        public void TaskB_OnlyFirst_OnlyLast()
        {
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2), new Seat('B', 1), new Seat('B', 2) };
            Show s = new Show("Avatar", "17:30-20:50", shows21Avatar);

            Viewer ferenc = new Viewer("Ferenc", s);
            ferenc.Reserve(s, 'A', 1, new Owner("Ferenc", Discount.Adult));
            ferenc.Purchase(s, 'B', 2, new Owner("Anna", Discount.Adult));

            Assert.IsTrue(shows21Avatar[0].state.IsReserved());
            Assert.IsTrue(shows21Avatar[3].state.IsSold());
            Assert.AreEqual(s.AvaCount(), 2);
            Assert.AreEqual(s.ResCount(), 1);
            Assert.AreEqual(s.SoldCount(), 1);
        }

        /*                      ha nincs adott tulajdonsagu elem (reserved)                   */
        [TestMethod]
        public void TaskB_None()
        {
            List<Seat> shows21Avatar = new List<Seat>() { new Seat('A', 1), new Seat('A', 2), new Seat('B', 1) };
            Show s = new Show("Avatar", "17:30-20:50", shows21Avatar);

            Assert.AreEqual(s.AvaCount(), 3);
            Assert.AreEqual(s.ResCount(), 0);
            Assert.AreEqual(s.SoldCount(), 0);
        }
    }
}