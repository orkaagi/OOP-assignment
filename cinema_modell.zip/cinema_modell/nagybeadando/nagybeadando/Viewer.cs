﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nagybeadando
{
    public class UnsuccessfulRequest : Exception { }

    public class Viewer
    {
        private readonly string name;
        private readonly Show show;
        private List<Seat> tickets = new();

        public Viewer(string name, Show show)
        {
            this.name = name;
            this.show = show;
        }
                
        public void Reserve(Show show, char row, int num, Owner o) {
            // linearis kereses
            bool l = false;
            int ind = 0;
            for (int i = 0; i < show.seats.Count; i++) 
            {
                if (show.seats[i].row == row && show.seats[i].num == num)
                {
                    l = true;
                    ind = i;
                    break;
                }
            }
            // jegy lefoglalasa           
            if (l && show.seats[ind].state.IsAvailable())
            {
                show.seats[ind].Reserve(o);
                tickets.Add(show.seats[ind]);
            }
            else throw new UnsuccessfulRequest();
        }

        public void Purchase(Show show, char row, int num, Owner o)
        {
            // linearis kereses
            bool l = false;
            int ind = 0;
            for (int i = 0; i < show.seats.Count; i++)
            {
                if (show.seats[i].row == row && show.seats[i].num == num)
                {
                    l = true;
                    ind = i;
                    break;
                }
            }
            // jegy megvasarlasa
            if (l && show.seats[ind].state.IsAvailable())
            {
                show.seats[ind].Sell(o);
                tickets.Add(show.seats[ind]);
            }
            // IsReserved => nem null!
            else if (l && show.seats[ind].state.IsReserved() && show.seats[ind].owner.name == o.name) 
            {
                show.seats[ind].Sell(o);
            }
            else throw new UnsuccessfulRequest();
        }

    }
}
